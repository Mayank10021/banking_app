import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/WithdrawServlet")
public class WithdrawServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        double amount = Double.parseDouble(request.getParameter("amount"));
        HttpSession session = request.getSession();
        Integer accountId = (Integer) session.getAttribute("user_id");

        Connection conn = DatabaseConnection.getConnection();
        String sql = "SELECT balance FROM accounts WHERE account_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, accountId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next() && rs.getDouble("balance") >= amount) {
                // Update account balance
                sql = "UPDATE accounts SET balance = balance - ? WHERE account_id = ?";
                try (PreparedStatement stmt2 = conn.prepareStatement(sql)) {
                    stmt2.setDouble(1, amount);
                    stmt2.setInt(2, accountId);
                    int rowsUpdated = stmt2.executeUpdate();

                    if (rowsUpdated > 0) {
                        // Log transaction
                        sql = "INSERT INTO transactions (account_id, transaction_type, amount) VALUES (?, 'Withdraw', ?)";
                        try (PreparedStatement stmt3 = conn.prepareStatement(sql)) {
                            stmt3.setInt(1, accountId);
                            stmt3.setDouble(2, amount);
                            stmt3.executeUpdate();
                        }

                        // Update the balance in the session
                        sql = "SELECT balance FROM accounts WHERE account_id = ?";
                        try (PreparedStatement stmt4 = conn.prepareStatement(sql)) {
                            stmt4.setInt(1, accountId);
                            ResultSet rs2 = stmt4.executeQuery();
                            if (rs2.next()) {
                                session.setAttribute("balance", rs2.getDouble("balance"));
                            }
                        }
                        response.sendRedirect("dashboard.jsp");
                    } else {
                        response.sendRedirect("dashboard.jsp?error=Withdrawal failed");
                    }
                }
            } else {
                response.sendRedirect("dashboard.jsp?error=Insufficient balance");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?error=Database error during withdrawal");
        } finally {
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}